package com.jeecms.common.web.session.id;

/**
 * session id 生成接口
 * 
 * @author liufang
 * 
 */
public interface SessionIdGenerator {
	public String get();
}
