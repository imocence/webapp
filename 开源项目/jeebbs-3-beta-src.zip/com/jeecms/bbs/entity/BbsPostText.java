﻿package com.jeecms.bbs.entity;

import com.jeecms.bbs.entity.base.BaseBbsPostText;



public class BbsPostText extends BaseBbsPostText {
	private static final long serialVersionUID = 1L;

/*[CONSTRUCTOR MARKER BEGIN]*/
	public BbsPostText () {
		super();
	}

	/**
	 * Constructor for primary key
	 */
	public BbsPostText (java.lang.Integer id) {
		super(id);
	}

/*[CONSTRUCTOR MARKER END]*/


}