package com.jeecms.cms.entity.assist;

import com.jeecms.cms.entity.assist.base.BaseCmsCommentExt;



public class CmsCommentExt extends BaseCmsCommentExt {
	private static final long serialVersionUID = 1L;

/*[CONSTRUCTOR MARKER BEGIN]*/
	public CmsCommentExt () {
		super();
	}

	/**
	 * Constructor for primary key
	 */
	public CmsCommentExt (java.lang.Integer id) {
		super(id);
	}

/*[CONSTRUCTOR MARKER END]*/


}