package org.jeecgframework.core.util;

public enum BrowserType {
	IE10,IE9,IE8,IE7,IE6,Firefox,Safari,Chrome,Opera,Camino,Gecko
}
