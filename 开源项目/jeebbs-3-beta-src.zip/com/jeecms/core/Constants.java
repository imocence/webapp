package com.jeecms.core;

/**
 * jeecore 常量
 * 
 * @author liufang
 * 
 */
public class Constants {
}
