package com.jeecms.cms.entity.back;

import com.jeecms.cms.entity.back.base.BaseCmsConstraints;

public class CmsConstraints extends BaseCmsConstraints {
	private static final long serialVersionUID = 1L;

	/* [CONSTRUCTOR MARKER BEGIN] */
	public CmsConstraints() {
		super();
	}

	/* [CONSTRUCTOR MARKER END] */

}