package com.jeecms.cms.entity.back;

import com.jeecms.cms.entity.back.base.BaseCmsField;

public class CmsField extends BaseCmsField {
	private static final long serialVersionUID = 1L;

	/* [CONSTRUCTOR MARKER BEGIN] */
	public CmsField() {
		super();
	}

	/* [CONSTRUCTOR MARKER END] */

}