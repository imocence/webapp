package jeecg.demo.service.test;

import org.jeecgframework.core.common.service.CommonService;


public interface JeecgDemoServiceI extends CommonService{

}
