package com.jeecms.bbs.entity;

import com.jeecms.bbs.entity.base.BaseBbsLoginLog;



public class BbsLoginLog extends BaseBbsLoginLog {
	private static final long serialVersionUID = 1L;

/*[CONSTRUCTOR MARKER BEGIN]*/
	public BbsLoginLog () {
		super();
	}

	/**
	 * Constructor for primary key
	 */
	public BbsLoginLog (java.lang.Integer id) {
		super(id);
	}

/*[CONSTRUCTOR MARKER END]*/


}