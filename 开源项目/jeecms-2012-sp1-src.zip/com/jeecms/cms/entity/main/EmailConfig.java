package com.jeecms.cms.entity.main;

import com.jeecms.cms.entity.main.base.BaseEmailConfig;



public class EmailConfig extends BaseEmailConfig {
	private static final long serialVersionUID = 1L;

/*[CONSTRUCTOR MARKER BEGIN]*/
	public EmailConfig () {
		super();
	}

/*[CONSTRUCTOR MARKER END]*/


}