package com.jeecms.cms.entity.back;

import com.jeecms.cms.entity.back.base.BaseCmsTable;

public class CmsTable extends BaseCmsTable {
	private static final long serialVersionUID = 1L;

	/* [CONSTRUCTOR MARKER BEGIN] */
	public CmsTable() {
		super();
	}

	/* [CONSTRUCTOR MARKER END] */

}