package com.jeecms.cms.service;

public interface AcquisitionSvc {
	public boolean start(Integer id);
}
