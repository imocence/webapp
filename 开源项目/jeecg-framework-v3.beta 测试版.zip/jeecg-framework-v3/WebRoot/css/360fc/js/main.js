//焦点图
$(document).ready(function() {
	$('#flashbox').smallslider({
	 onImageStop : false,
	 switchEffect : 'ease',
	 switchEase : 'easeOutBounce',
	 switchPath : 'up',
	 switchMode : 'hover',
	 textSwitch : 2,
	 textPosition : 'top',
	 textAlign : 'center'
	});
});
