package com.jeecms.cms.action.member;

import java.util.Date;

/**
 *江西金磊科技发展有限公司jeecms研发
 */

public class MessageTask {
	// 定时清理会员的垃圾信息
	public void deleteMsgBackstage() {

	}
}
